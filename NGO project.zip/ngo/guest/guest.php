

<link href="../css/style.css" rel="stylesheet" type="text/css" />
<?php
include'gheader.php';

$un=$_REQUEST['username'];
?>

<center><h1 class="color" > Guest</h1></center>
