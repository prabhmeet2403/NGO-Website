 <hr>

<footer class="container-fluid text-center">
  <p>Donate For Poor Peoples</p>
 
</footer>

</body>
</html>

