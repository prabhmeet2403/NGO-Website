<link rel="stylesheet" href="css/style.css" type="text/css" />


<?php
include'header.php';
?>


<div style="background-color:#FBF1B6" >
<div  style="margin-top:100px">
<div id="middle_1">

   <br />	
    <h1 style="color:#000; padding:10px 0 0 0px;">   Special Tahnks To Our Supports</h1><br>
    <div  style="float:left">
    
    
    
    
        </div>
       
        </div>
<hr  />
<?php
include'footer.php';
?>