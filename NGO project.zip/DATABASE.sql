/*
SQLyog - Free MySQL GUI v5.17
Host - 5.1.53-community-log : Database - ngo
*********************************************************************
Server version : 5.1.53-community-log
*/

SET NAMES utf8;

SET SQL_MODE='';

create database if not exists `ngo`;

USE `ngo`;

SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO';

/*Table structure for table `blog` */

DROP TABLE IF EXISTS `blog`;

CREATE TABLE `blog` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `username` varchar(30) DEFAULT NULL,
  `title` varchar(30) DEFAULT NULL,
  `comment` varchar(100) DEFAULT NULL,
  `image` varchar(20) DEFAULT NULL,
  `date` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

/*Data for the table `blog` */

insert into `blog` (`id`,`username`,`title`,`comment`,`image`,`date`) values (1,'guest','kkk','hello  welcome','a5.jpg','2013-2-1');
insert into `blog` (`id`,`username`,`title`,`comment`,`image`,`date`) values (2,'guest','kkk','hello  welcome','a5.jpg','2013-2-1');
insert into `blog` (`id`,`username`,`title`,`comment`,`image`,`date`) values (3,'guest','health','health  facilites  should  be  best','Koala.jpg','2013-2-2-');
insert into `blog` (`id`,`username`,`title`,`comment`,`image`,`date`) values (4,'guest','sssss','eer','download (3).jpg','12-12-12');

/*Table structure for table `complain` */

DROP TABLE IF EXISTS `complain`;

CREATE TABLE `complain` (
  `cfor` varchar(100) DEFAULT NULL,
  `cto` varchar(100) DEFAULT NULL,
  `date` varchar(100) DEFAULT NULL,
  `complain` varchar(1000) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

/*Data for the table `complain` */

insert into `complain` (`cfor`,`cto`,`date`,`complain`) values ('kjgkj','lkh','2014-04-09','kllj');
insert into `complain` (`cfor`,`cto`,`date`,`complain`) values ('meet','bawa','2014-04-17','ljjbkjb');
insert into `complain` (`cfor`,`cto`,`date`,`complain`) values ('sures','ww','2020-04-27','sdfsdfsdfsdf\r\nbad');

/*Table structure for table `donator` */

DROP TABLE IF EXISTS `donator`;

CREATE TABLE `donator` (
  `ngo` varchar(100) DEFAULT NULL,
  `donation` varchar(100) DEFAULT NULL,
  `amt` varchar(100) DEFAULT NULL,
  `card` varchar(100) DEFAULT NULL,
  `date` varchar(100) DEFAULT NULL,
  `contact` bigint(20) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

/*Data for the table `donator` */

insert into `donator` (`ngo`,`donation`,`amt`,`card`,`date`,`contact`,`name`,`email`) values ('Uddan','on','76','67','75',77,'87','79');
insert into `donator` (`ngo`,`donation`,`amt`,`card`,`date`,`contact`,`name`,`email`) values ('Uddan','on','20000','231','2020-04-28',883838,'amrit singh','abcinfo@gmail.com');
insert into `donator` (`ngo`,`donation`,`amt`,`card`,`date`,`contact`,`name`,`email`) values ('Uddan','on','20000','1232132132','2020-04-14',131,'123','123');

/*Table structure for table `event` */

DROP TABLE IF EXISTS `event`;

CREATE TABLE `event` (
  `event_id` bigint(15) NOT NULL AUTO_INCREMENT,
  `event_name` varchar(100) NOT NULL,
  `event_description` text NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL,
  `address` text NOT NULL,
  `city_id` int(5) NOT NULL,
  `duration` varchar(10) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`event_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

/*Data for the table `event` */

insert into `event` (`event_id`,`event_name`,`event_description`,`date`,`time`,`address`,`city_id`,`duration`,`image`) values (7,'English Commune','Providing Education on English commune','2020-04-28','14:00:00','Kharar',0,'4 Hours','03.jpg');
insert into `event` (`event_id`,`event_name`,`event_description`,`date`,`time`,`address`,`city_id`,`duration`,`image`) values (8,'Social Distance','Providing Education on Social Distance','2020-04-28','14:00:00','Kharar',0,'5 Hours','01.jpg');
insert into `event` (`event_id`,`event_name`,`event_description`,`date`,`time`,`address`,`city_id`,`duration`,`image`) values (9,'Abacus Calculation','Describing tips of math for students','2020-04-30','13:00:00','Amritsar,',0,'2 days','09.jpg');
insert into `event` (`event_id`,`event_name`,`event_description`,`date`,`time`,`address`,`city_id`,`duration`,`image`) values (10,'Geographical Effects','Describing Effects ','2020-05-20','13:00:00','Patiala',0,'5 days','10.jpg');
insert into `event` (`event_id`,`event_name`,`event_description`,`date`,`time`,`address`,`city_id`,`duration`,`image`) values (11,'Pollution Control','Describing Pollution Effects','2020-05-20','13:00:00','Patiala',0,'5 days','07.jpg');

/*Table structure for table `facilitychild` */

DROP TABLE IF EXISTS `facilitychild`;

CREATE TABLE `facilitychild` (
  `education` varchar(100) DEFAULT NULL,
  `cloth` varchar(100) DEFAULT NULL,
  `food` varchar(100) DEFAULT NULL,
  `game` varchar(100) DEFAULT NULL,
  `med` varchar(100) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

/*Data for the table `facilitychild` */

insert into `facilitychild` (`education`,`cloth`,`food`,`game`,`med`) values ('secondary','summer','breakfast','','rrr');
insert into `facilitychild` (`education`,`cloth`,`food`,`game`,`med`) values ('primary','winter','dinner','','bbb');
insert into `facilitychild` (`education`,`cloth`,`food`,`game`,`med`) values ('primary','winter','dinner','vvv','hhjh');
insert into `facilitychild` (`education`,`cloth`,`food`,`game`,`med`) values ('primary','winter','lunch','12','3');
insert into `facilitychild` (`education`,`cloth`,`food`,`game`,`med`) values ('secondary','summer','lunch','533','355');

/*Table structure for table `facilityold` */

DROP TABLE IF EXISTS `facilityold`;

CREATE TABLE `facilityold` (
  `cloth` varchar(100) DEFAULT NULL,
  `food` varchar(100) DEFAULT NULL,
  `med` varchar(100) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

/*Data for the table `facilityold` */

insert into `facilityold` (`cloth`,`food`,`med`) values ('winter','breakfast','ggg');

/*Table structure for table `login` */

DROP TABLE IF EXISTS `login`;

CREATE TABLE `login` (
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `cpassword` varchar(50) DEFAULT NULL,
  `type` varchar(50) DEFAULT NULL,
  `fullname` varchar(50) DEFAULT NULL,
  `dob` varchar(50) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `s_ques` varchar(1000) DEFAULT NULL,
  `s_ans` varchar(1000) DEFAULT NULL,
  `address` varchar(500) DEFAULT NULL,
  `country` varchar(100) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `state` varchar(100) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

/*Data for the table `login` */

insert into `login` (`username`,`password`,`cpassword`,`type`,`fullname`,`dob`,`email`,`s_ques`,`s_ans`,`address`,`country`,`city`,`state`) values ('guest','guest','guest','guest','aa','04/15/2014','What','dcd','s@.com','nbvbh','jhkh','ffdd','dff');
insert into `login` (`username`,`password`,`cpassword`,`type`,`fullname`,`dob`,`email`,`s_ques`,`s_ans`,`address`,`country`,`city`,`state`) values ('admin','admin','admin','admin','hghj','04/02/2014','What','jkh','jb@.com','uuig','kugu','kgh','kjg');
insert into `login` (`username`,`password`,`cpassword`,`type`,`fullname`,`dob`,`email`,`s_ques`,`s_ans`,`address`,`country`,`city`,`state`) values ('donator','donator','donator','donator','hghj','04/02/2014','What','jkh','jb@.com','uuig','kugu','kgh','pppp');

/*Table structure for table `persons` */

DROP TABLE IF EXISTS `persons`;

CREATE TABLE `persons` (
  `name` varchar(20) DEFAULT NULL,
  `age` int(20) DEFAULT NULL,
  `gender` varchar(20) DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL,
  `address` varchar(20) DEFAULT NULL,
  `country` varchar(20) DEFAULT NULL,
  `state` varchar(20) DEFAULT NULL,
  `city` varchar(20) DEFAULT NULL,
  `image` varchar(20) DEFAULT NULL,
  `type1` varchar(20) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

/*Data for the table `persons` */

insert into `persons` (`name`,`age`,`gender`,`date_of_birth`,`address`,`country`,`state`,`city`,`image`,`type1`) values ('kk',8,'male','2011-02-02','kk                 ','inida','hry','ambala','a.jpg','child');
insert into `persons` (`name`,`age`,`gender`,`date_of_birth`,`address`,`country`,`state`,`city`,`image`,`type1`) values ('haria',67,'male','1976-02-02','sec 34              ','i','','','','oldperson');
insert into `persons` (`name`,`age`,`gender`,`date_of_birth`,`address`,`country`,`state`,`city`,`image`,`type1`) values ('haria1',67,'male','1976-02-02','sec 34              ','INDIA','hry','chandigarh','5.jpeg','oldperson');
insert into `persons` (`name`,`age`,`gender`,`date_of_birth`,`address`,`country`,`state`,`city`,`image`,`type1`) values ('rajesh',40,'male','0000-00-00','hno	                ','chd','cgd','ee','1234.png','oldperson');
insert into `persons` (`name`,`age`,`gender`,`date_of_birth`,`address`,`country`,`state`,`city`,`image`,`type1`) values ('aman',9,'male','0000-00-00','22             ','2','2','2','ones.jpg','oldperson');

/*Table structure for table `poorchild` */

DROP TABLE IF EXISTS `poorchild`;

CREATE TABLE `poorchild` (
  `id` int(10) DEFAULT NULL,
  `namengo` varchar(100) DEFAULT NULL,
  `loc` varchar(100) DEFAULT NULL,
  `people` varchar(100) DEFAULT NULL,
  `child` varchar(100) DEFAULT NULL,
  `oldpeople` varchar(100) DEFAULT NULL,
  `doctor` varchar(100) DEFAULT NULL,
  `helper` varchar(100) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

/*Data for the table `poorchild` */

insert into `poorchild` (`id`,`namengo`,`loc`,`people`,`child`,`oldpeople`,`doctor`,`helper`) values (1,'Uddan','gjjhg','o','gukj','jgk','kh','kjg');
insert into `poorchild` (`id`,`namengo`,`loc`,`people`,`child`,`oldpeople`,`doctor`,`helper`) values (2,'Uddan','a','b','c','d','e','f');
insert into `poorchild` (`id`,`namengo`,`loc`,`people`,`child`,`oldpeople`,`doctor`,`helper`) values (123,'Uddan','chan','12','3','1','2','2');

SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
